package com.johncastle.actividad1.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.johncastle.actividad1.R

class Splash : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)


        Handler().postDelayed({
            //----------------------------
            //con este codigo al dar clic mandamos a una segunda ventana
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
            finish()
            //----------------------------
        }, 5000) //5000 millisegundos = 5 segundos.

    }
}