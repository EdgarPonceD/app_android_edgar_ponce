package com.johncastle.actividad1.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.johncastle.actividad1.R

class MainActivity2 : AppCompatActivity() {

    val myString = "Hey there!"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /*AQUI INICIA LA DECLARACION PARA HACER REFERENCIA A UN BOTON*/

        val login=findViewById<Button>(R.id.btnCalculadora)
        //variable validamos la caja de texto
        val texNombre=findViewById<EditText>(R.id.IdNombre1)
        val texPass=findViewById<EditText>(R.id.IdContraseña)
        //con esta variable se ejecuta el splash de manera automatica
        //val intent = Intent(this,Splash::class.java)
        //startActivity(intent)

        /*VARIABLE   NOMBRE=LOGIN   ENCUENTRA LA VISTA =findViewById<Button>  TIPO DE ELEMENTO = BOTTON
        VINCULA CON EL ID DEL ELEMENTO (R.id.IdBoton)*/
        /*login.setText("HOLA DESDE CODIGO")*/

        //EVENTO QUE CAMBIARA EL NOMBRE AL MOMENTO DE DAR CLIC AL BOTON
        login.setOnClickListener({
            //login.setText("INVALIDOS")
            //con este if validamos si edgar es igual a edgar entra a la segunda ventana.
            if (texNombre.text.toString().equals("edgar")) {
                // Código a ejecutar si la condición1 es verdadera
                if (texPass.text.toString().equals("1234")) {
                    // Código a ejecutar si ambas condiciones son verdaderas
                    //con este codigo al dar clic mandamos a una segunda ventana
                    val intent = Intent(this,Menu::class.java)
                    startActivity(intent)
                    //se coloca despues de que se manda a una segunda ventana
                    finish()
                    //mensaje flotante de inicio de sesion valido
                    Toast.makeText(
                        this,"bienvenido inicio de sesion correcto", Toast.LENGTH_SHORT
                    ).show()
                } else {
                    // Código a ejecutar si la condición1 es verdadera pero la condición2 no lo es
                    //con este comando mandamos un mensaje flotante si la condicion2 es false
                    Toast.makeText(
                        this,"contraseña incorrectos", Toast.LENGTH_SHORT).show()
                }
            } else {
                // Código a ejecutar si la condición1 es falsa
                //con este comando mandamos un mensaje flotante si la condicion1 es false
                Toast.makeText(
                    this,"usuario incorrecto", Toast.LENGTH_SHORT).show()
            }


           /* //con este if validamos si textpass como cadena de caracteres es igual a 1234
            if(texPass.text.toString().equals("1234")){

            }
            //si no muestra mensaje contraseña es incorrecta con Toast
            else{
                //mensaje flotante
                Toast.makeText(
                    this,"contraseña incorrecta", Toast.LENGTH_SHORT
                ).show()
            }*/

        })

        //Toast.make
//TAREA MODIFICAR LA VISTA Y HACER SUMA Y RESTA CREAR UNA VISTA, EN SU METODO PRINCIPAL ONCREATE HACER LA ASIGNACION DE LAS VARIABLES
    }
}