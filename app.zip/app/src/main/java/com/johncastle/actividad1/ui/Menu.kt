package com.johncastle.actividad1.ui


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.johncastle.actividad1.R
import org.w3c.dom.Text

//crea la clase menu y se manda appcompat para poder jalar la actividad
//desde el androidmanifest
class Menu : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menu)
        val btn_calculadora = findViewById<Button>(R.id.btnCalculadora)
        val btn_cerrarSesion = findViewById<Button>(R.id.btnCerrarSesion)
        val btn_Agenda = findViewById<Button>(R.id.btnAgenda)

        //con este codigo al dar clic mandamos a una segunda ventana
        btn_calculadora.setOnClickListener({
            val intent = Intent(this, SegundaActividad::class.java)
            startActivity(intent)
            finish()
        }
        )

        btn_Agenda.setOnClickListener({
            val intent = Intent(this, Reporte::class.java)
            startActivity(intent)
            finish()
        }
        )

        btn_cerrarSesion.setOnClickListener({
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
            finish()
        })


    }
}