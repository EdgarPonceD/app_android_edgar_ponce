package com.johncastle.actividad1.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.johncastle.actividad1.R

class SegundaActividad : AppCompatActivity() {
    //private val handler = Handler(): Esta línea crea una instancia de la clase Handler. Un Handler
    // es una clase de Android que permite programar tareas para ser ejecutadas en un momento
    // específico en el futuro o en otro hilo de ejecución. En este contexto, se utiliza para
    // programar la actualización del TextView en intervalos regulares. La palabra clave val
    // indica que handler es una propiedad inmutable, lo que significa que no se puede reasignar
    // después de su inicialización.
    private val handler = Handler()
    //private var contador = 1: Esta línea declara una variable llamada contador e inicializa su valor
    // en 1. La palabra clave var indica que contador es una propiedad mutable, lo que significa que
    // su valor puede cambiar después de la inicialización. Se utiliza para mantener un seguimiento
    // del número actual que se está mostrando en el TextView.
    private var contador = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda_actividad)
        val n1=findViewById<EditText>(R.id.caj_texto1)
        val n2=findViewById<EditText>(R.id.caj_texto2)
        val r=findViewById<TextView>(R.id.textView2)
        val btn_sumar=findViewById<Button>(R.id.botonOperacion)
        val btn_resta=findViewById<Button>(R.id.botonResta)
        val btn_multipli=findViewById<Button>(R.id.botonmultiplicacion)
        val btn_division=findViewById<Button>(R.id.btonDivision)
        val btn_MenuCal=findViewById<Button>(R.id.btnMenuCalc)
        val btn_cicloFor=findViewById<Button>(R.id.btnCicloFor)
        val numeros = StringBuilder()
        val texView_cicloFor=findViewById<TextView>(R.id.textViewCicloFor)



        //actualizarTextView();

        btn_sumar.setOnClickListener {
            r.setText(
                "LA SUMA ES: " +(n1.text.toString().toInt()+n2.text.toString().toInt())
            )
        }
        btn_resta.setOnClickListener {
            r.setText(
                "LA RESTA ES : " +(n1.text.toString().toInt()-n2.text.toString().toInt())
            )
        }

        btn_multipli.setOnClickListener {
            r.setText(
                "LA MULTIPLICACION ES : " +(n1.text.toString().toInt()*n2.text.toString().toInt())
            )
        }

        btn_division.setOnClickListener {
            r.setText(
                "LA DIVISION ES : " +(n1.text.toString().toInt()/n2.text.toString().toInt())
            )
        }
        btn_MenuCal.setOnClickListener({
            //con este codigo al dar clic mandamos a una segunda ventana
            val intent = Intent(this, Menu::class.java)
            startActivity(intent)
            finish()
        }
        )
        //con este evento al momento de dar clic ejecutamos el ciclo for de 1 en 1 hasta
        // llegar al 30 se detiene

        //con este codigo ejecutamos cada clic en ciclo for
       btn_cicloFor.setOnClickListener({


            //se verifica si el contador es menor o igual a 30, si es verdadero
            //se ejecutara el bloque de codigo
            if (contador <= 30){
                //se agrega el valor actual de 'contador' seguido de una coma y un espacio
                //se utiliza el signo $ para incrustar el valor de contador en la cadena
                texView_cicloFor.append("$contador, ")
                //esto incrementa el valor de contador en 1 después de
                // que se ha agregado al textView_cicloFor.
                contador++
                //programa una tarea para que se ejecute despues de un cierto retraso,
                //retraso de 1000 milisegundos
                handler.postDelayed({ texView_cicloFor}, 1000)

                }

        }

        )
/*
run {
    Handler().postDelayed({
        //----------------------------
        //con este codigo al dar clic mandamos a una segunda ventana

        if (contador <= 30) {
            //se agrega el valor actual de 'contador' seguido de una coma y un espacio
            //se utiliza el signo $ para incrustar el valor de contador en la cadena
            texView_cicloFor.append("$contador, ")
            //esto incrementa el valor de contador en 1 después de
            // que se ha agregado al textView_cicloFor.
            contador++
            //programa una tarea para que se ejecute despues de un cierto retraso,
            //retraso de 1000 milisegundos

            //handler.postDelayed({ texView_cicloFor}, 0)


        }

        //----------------------------
    }, 5000) //5000 millisegundos = 5 segundos.


}*/
        /*btn_cicloFor.setOnClickListener({
            for (i in 1..30){
                numeros.append("$i, ")
            }
            texView_cicloFor.text=numeros.toString()

        })*/


        //btn_cierraSesion.setOnClickListener({
          //  val intent = Intent(this, MainActivity2::class.java)
            //startActivity(intent)
        //}


        //)

        /*val stringBuilder = stringBuilder()
        for (i in 1..30) {
            stringBuilder.append("$i, ")
        }

        // Eliminar la coma y el espacio del final
        val series = stringBuilder.toString().dropLast(2)

        // Mostrar la serie en el TextView
        textView.textViewCicloFor = series*/






    }
}