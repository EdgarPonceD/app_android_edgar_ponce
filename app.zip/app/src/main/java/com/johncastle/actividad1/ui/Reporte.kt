package com.johncastle.actividad1.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Vibrator
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.johncastle.actividad1.R


class Reporte : AppCompatActivity(){
    private val handler = Handler()
    //private var contador = 1: Esta línea declara una variable llamada contador e inicializa su valor
    // en 1. La palabra clave var indica que contador es una propiedad mutable, lo que significa que
    // su valor puede cambiar después de la inicialización. Se utiliza para mantener un seguimiento
    // del número actual que se está mostrando en el TextView.
    private var contador = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.reporte)

        val btn_anadeRegistros = findViewById<Button>(R.id.btnAnade)
        val textView_cicloFor = findViewById<TextView>(R.id.ListArreglo)
        val texto_nombres = findViewById<EditText>(R.id.textreportes)
        val btn_regresamenu = findViewById<Button>(R.id.btnMenuReporte)
        val btn_reiniciar = findViewById<Button>(R.id.btnreinicia)

        //con este boton es para ir añadiendo registros al arreglo
        btn_anadeRegistros.setOnClickListener({

            // Obtener el texto ingresado en la caja de texto
            val nombre = texto_nombres.text.toString()

            // Verificar si el contador es menor o igual a 5
            if (contador <= 5){
                // Agregar el nombre al TextView
                textView_cicloFor.append("$nombre, ")

                // Limpiar la caja de texto
                texto_nombres.setText("")

                // Incrementar el contador
                contador++
            }

        }

        )
        var vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator

        //con este boton regresamos al menu.
        btn_regresamenu.setOnClickListener({
            vibrator.vibrate(1000)
            //con este codigo al dar clic mandamos a una segunda ventana
            val intent = Intent(this, Menu::class.java)
            startActivity(intent)
            finish()
        }
        )
        //con este boton reiniciamos el contrador del textview
        btn_reiniciar.setOnClickListener({
            // Borrar el contenido del TextView
            textView_cicloFor.text = ""

            // Reiniciar el contador
            contador = 1
        })




        }



    }

